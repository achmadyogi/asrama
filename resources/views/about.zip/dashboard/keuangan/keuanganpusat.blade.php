@foreach($data as $data)
    {{$data->nim}}
@endforeach
This is it